__title__ = "sail-data-layer"
__author__ = "jaap@secureailabs.com"
__license__ = ""
__copyright__ = "Copyright 2023-present Secure AI labs"
__version__ = "1.0.1"  # https://peps.python.org/pep-0440/
